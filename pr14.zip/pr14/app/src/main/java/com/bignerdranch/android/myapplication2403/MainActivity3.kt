package com.bignerdranch.android.myapplication2403

import android.annotation.SuppressLint
import android.content.Intent
import android.support.v7.app.AppCompatActivity
import android.os.Bundle
import android.view.Gravity
import android.view.View
import android.widget.Button
import android.widget.Toast

class MainActivity3 : AppCompatActivity() {
    private lateinit var trueButton: Button
    private lateinit var falseButton: Button
    private lateinit var ButtonNext: Button
    @SuppressLint("MissingInflatedId")
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main3)

        trueButton=findViewById(R.id.true_button)
        falseButton=findViewById(R.id.false_button)
        ButtonNext=findViewById(R.id.next_button)


        trueButton.setOnClickListener { view: View ->
            var t= Toast.makeText(this,R.string.correct, Toast.LENGTH_SHORT)
            t.setGravity(Gravity.TOP,0,0)
            t.show()
        }
        falseButton.setOnClickListener { view: View ->
            var t= Toast.makeText(this,R.string.incorrect, Toast.LENGTH_SHORT)
            t.setGravity(Gravity.TOP,0,0)
            t.show()
        }
        ButtonNext.setOnClickListener { view: View ->
            val intent= Intent(this,MainActivity4::class.java)
            startActivity(intent)
        }
    }
}